VSOMEIP_CONFIGURATION=../json/vsomeip_server.json VSOMEIP_APPLICATION_NAME=service-sample ./cluster
