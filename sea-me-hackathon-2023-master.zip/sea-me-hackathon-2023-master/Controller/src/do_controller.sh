VSOMEIP_CONFIGURATION=../json/vsomeip_client.json VSOMEIP_APPLICATION_NAME=client-sample ./controller
